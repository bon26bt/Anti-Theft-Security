package com.bonat.antitheft

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // Bilbilli deebi'ee yeroo ka'u safe-area irra deebi'ee galmeessa.
            GeofenceHelper.registerFromPrefs(context)
        }
    }
}
