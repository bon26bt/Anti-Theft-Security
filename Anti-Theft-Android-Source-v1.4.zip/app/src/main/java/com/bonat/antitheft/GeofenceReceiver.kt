package com.bonat.antitheft

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent
import kotlin.concurrent.thread

class GeofenceReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val event = GeofencingEvent.fromIntent(intent) ?: return
        if (event.hasError()) return
        val (message, emailEvent) = when (event.geofenceTransition) {
            Geofence.GEOFENCE_TRANSITION_EXIT ->
                context.getString(R.string.notif_left) to "Your phone has LEFT the safe area."
            Geofence.GEOFENCE_TRANSITION_ENTER ->
                context.getString(R.string.notif_returned) to "Your phone has RETURNED to the safe area."
            else -> return
        }
        GeofenceHelper.ensureChannel(context)
        val notification = NotificationCompat.Builder(context, GeofenceHelper.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(context.getString(R.string.notif_title))
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true).build()
        try { NotificationManagerCompat.from(context).notify(1001, notification) } catch (_: SecurityException) {}

        val loc = event.triggeringLocation
        val pending = goAsync()
        thread {
            try { AlertBackend.sendEventBlocking(emailEvent, loc?.latitude, loc?.longitude) }
            finally { pending.finish() }
        }
    }
}
