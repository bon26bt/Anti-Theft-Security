package com.bonat.antitheft

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices

object GeofenceHelper {
    const val CHANNEL_ID = "anti_theft_alerts"
    const val ACTION = "com.bonat.antitheft.GEOFENCE_EVENT"

    fun ensureChannel(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, context.getString(R.string.channel_name), NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, GeofenceReceiver::class.java).setAction(ACTION)
        // Geofencing PendingIntent MUTABLE ta'uu qaba.
        return PendingIntent.getBroadcast(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )
    }

    fun hasFine(context: Context) =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun hasBackground(context: Context) =
        android.os.Build.VERSION.SDK_INT < 29 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Safe-area kuufame prefs irraa dubbisee galmeessa. true = yaalii eegale. */
    @SuppressLint("MissingPermission")
    fun registerFromPrefs(context: Context, onResult: ((Boolean, String?) -> Unit)? = null): Boolean {
        val prefs = context.getSharedPreferences("anti_theft", Context.MODE_PRIVATE)
        val lat = prefs.getString("lat", null)?.toDoubleOrNull()
        val lon = prefs.getString("lon", null)?.toDoubleOrNull()
        val r = prefs.getString("radius", null)?.toFloatOrNull()
        if (lat == null || lon == null || r == null || !hasFine(context) || !hasBackground(context)) return false
        if (!prefs.getBoolean("enabled", true)) return false
        val geofence = Geofence.Builder()
            .setRequestId("MY_SAFE_AREA")
            .setCircularRegion(lat, lon, r)
            .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_EXIT or Geofence.GEOFENCE_TRANSITION_ENTER)
            .setExpirationDuration(Geofence.NEVER_EXPIRE)
            .build()
        val request = GeofencingRequest.Builder()
            .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
            .addGeofence(geofence).build()
        LocationServices.getGeofencingClient(context)
            .addGeofences(request, pendingIntent(context))
            .addOnSuccessListener { onResult?.invoke(true, null) }
            .addOnFailureListener { onResult?.invoke(false, it.localizedMessage) }
        return true
    }
}
