package com.bonat.antitheft

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import com.google.android.gms.location.LocationServices

class MainActivity : AppCompatActivity() {
    private val reqBasic = 710
    private val reqBackground = 711
    private val prefs by lazy { getSharedPreferences("anti_theft", MODE_PRIVATE) }
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        GeofenceHelper.ensureChannel(this)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        layout.addView(TextView(this).apply { text = getString(R.string.title); textSize = 24f })
        layout.addView(TextView(this).apply {
            text = getString(R.string.intro)
            textSize = 15f
        })
        val lat = EditText(this).apply {
            hint = getString(R.string.hint_lat); setText(prefs.getString("lat", "")); inputType = 12290
        }
        val lon = EditText(this).apply {
            hint = getString(R.string.hint_lon); setText(prefs.getString("lon", "")); inputType = 12290
        }
        val radius = EditText(this).apply {
            hint = getString(R.string.hint_radius); setText(prefs.getString("radius", "100")); inputType = 2
        }
        layout.addView(lat); layout.addView(lon); layout.addView(radius)

        layout.addView(Button(this).apply {
            text = getString(R.string.btn_use_location)
            setOnClickListener {
                if (!GeofenceHelper.hasFine(this@MainActivity)) {
                    ActivityCompat.requestPermissions(this@MainActivity, basicPerms(), reqBasic)
                    return@setOnClickListener
                }
                @Suppress("MissingPermission")
                LocationServices.getFusedLocationProviderClient(this@MainActivity).lastLocation
                    .addOnSuccessListener { l ->
                        if (l != null) { lat.setText(l.latitude.toString()); lon.setText(l.longitude.toString()) }
                        else toast(getString(R.string.toast_no_location))
                    }
            }
        })

        layout.addView(Button(this).apply {
            text = getString(R.string.btn_save)
            setOnClickListener {
                val a = lat.text.toString().toDoubleOrNull()
                val b = lon.text.toString().toDoubleOrNull()
                val r = radius.text.toString().toFloatOrNull()
                if (a == null || b == null || r == null || a !in -90.0..90.0 ||
                    b !in -180.0..180.0 || r < 50f) {
                    toast(getString(R.string.toast_invalid))
                } else {
                    prefs.edit().putString("lat", a.toString()).putString("lon", b.toString())
                        .putString("radius", r.toString()).putBoolean("enabled", true).apply()
                    ensurePermissionsAndRegister()
                }
            }
        })
        layout.addView(Button(this).apply {
            text = getString(R.string.btn_stop)
            setOnClickListener {
                prefs.edit().putBoolean("enabled", false).apply()
                LocationServices.getGeofencingClient(this@MainActivity)
                    .removeGeofences(GeofenceHelper.pendingIntent(this@MainActivity))
                setStatus(getString(R.string.status_stopped))
            }
        })
        status = TextView(this).apply { textSize = 14f; setPadding(0, pad / 2, 0, pad / 2) }
        layout.addView(status)
        layout.addView(TextView(this).apply {
            text = getString(R.string.footer, "bonsa26tefera@gmail.com")
            textSize = 13f
        })
        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        // Settings irraa deebi'ee yoo permission kenname, ofumaan galmeessa.
        if (prefs.getString("lat", null) != null && prefs.getBoolean("enabled", true) &&
            GeofenceHelper.hasFine(this) && GeofenceHelper.hasBackground(this)) {
            registerNow()
        } else refreshStatus()
    }

    private fun basicPerms(): Array<String> {
        val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        return p.toTypedArray()
    }

    private fun ensurePermissionsAndRegister() {
        when {
            !GeofenceHelper.hasFine(this) ->
                ActivityCompat.requestPermissions(this, basicPerms(), reqBasic)
            !GeofenceHelper.hasBackground(this) -> {
                if (Build.VERSION.SDK_INT >= 30) {
                    toast(getString(R.string.toast_allow_all_time))
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                } else {
                    ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), reqBackground)
                }
            }
            else -> registerNow()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (prefs.getString("lat", null) != null) ensurePermissionsAndRegister()
        else refreshStatus()
    }

    private fun registerNow() {
        GeofenceHelper.registerFromPrefs(this) { ok, err ->
            setStatus(if (ok) getString(R.string.status_ok) else getString(R.string.status_fail, err ?: ""))
        }
    }

    private fun refreshStatus() {
        val msg = when {
            !GeofenceHelper.hasFine(this) -> getString(R.string.status_need_location)
            !GeofenceHelper.hasBackground(this) -> getString(R.string.status_need_bg)
            else -> ""
        }
        setStatus(msg)
    }

    private fun setStatus(s: String) { if (::status.isInitialized) status.text = s }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
