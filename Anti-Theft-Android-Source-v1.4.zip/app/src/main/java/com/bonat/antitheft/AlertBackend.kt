package com.bonat.antitheft

import android.util.Log
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AlertBackend {
    /** Thread duwwaa irratti waamami (main thread irratti hin waamin). */
    fun sendEventBlocking(event: String, lat: Double?, lon: Double?) {
        if (BuildConfig.ALERT_URL.isBlank()) {
            Log.i("AntiTheft", "ALERT_URL hin qophoofne: $event")
            return
        }
        try {
            val body = JSONObject().apply {
                put("event", event)
                put("time", System.currentTimeMillis())
                if (lat != null && lon != null) { put("lat", lat); put("lon", lon) }
            }.toString()
            val conn = (URL(BuildConfig.ALERT_URL).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 10000
                readTimeout = 10000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Authorization", "Bearer ${BuildConfig.ALERT_TOKEN}")
            }
            conn.outputStream.use { it.write(body.toByteArray()) }
            Log.i("AntiTheft", "Backend response: ${conn.responseCode}")
            conn.disconnect()
        } catch (e: Exception) {
            Log.w("AntiTheft", "Backend error: ${e.message}")
        }
    }
}
